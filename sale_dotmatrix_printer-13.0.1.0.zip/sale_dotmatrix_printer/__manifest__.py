# -*- coding: utf-8 -*-

{
    'name': 'Sales Dotmatrix Printer',
    'version': '1.0',
    'category': 'Sale',
    'sequence': 6,
    'author': 'ErpMstar Solutions',
    'summary': 'Allows you to print sales report by dot matrix printer.',
    'description': "Allows you to print sales report by dot matrix printer.",
    'depends': ['sale'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'qweb': [
        # 'static/src/xml/pos.xml',
    ],
    'images': [
        'static/description/redc.jpg',
    ],
    'installable': True,
    'website': '',
    'auto_install': False,
    'price': 30,
    'currency': 'EUR',
}
