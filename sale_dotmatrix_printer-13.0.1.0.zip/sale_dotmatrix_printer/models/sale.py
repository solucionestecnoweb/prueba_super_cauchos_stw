# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools, _


class SaleDotmatrixReceipt(models.TransientModel):
    _name = 'sale.dotmatrix.receipt'

    name = fields.Char("Test")


class SaleOrder(models.Model):
    _inherit = "sale.order"
 
    # @api.multi
    def print_new_receipt(self):
        templ = self.env['mail.template'].search([('name', '=', 'Dot Matrix SO')])
        if templ:
            data = templ._render_template(templ[0].body_html, 'sale.order', self.id)
            view_id = self.env.ref('sale_dotmatrix_printer.sale_dotmatrix_receipt_form').id
            res = {
                "name":data,
            }
            wizard_id = self.env['sale.dotmatrix.receipt'].create(res)
            context = self._context.copy()
            return {
                'name':'Print Receipt',
                'view_type':'form',
                'view_mode':'tree',
                'views' : [(view_id,'form')],
                'res_model':'sale.dotmatrix.receipt',
                'view_id':view_id,
                'type':'ir.actions.act_window',
                'res_id':wizard_id.id,
                'target':'new',
                'context':context,
            }





